<?php


//Paramètre de connexion à la BDD
define('HOST', 'localhost');
define('BDD', 'commerce');
define('USER', 'root');
define('PASSWD', '');

//Connexion à la Base de donnée


try{
    $db = new PDO('mysql:host='. HOST .';dbname='. BDD, USER, PASSWD, array(
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"
    ));
} catch( PDOException $error) {
    throw new PDOException("La connexion à la base de données n'a pas fonctionnée");
}

?>