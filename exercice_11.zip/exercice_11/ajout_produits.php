<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Formulaire de produits</title>
</head>
<body>

<div class="container py-5 px-3">
    <H1>Formulaire de produits</H1>

    <form action="verification_produits.php" method="post">


       
        <div class="form-group">
            <label for="nom">Nom</label>
            <input type="nom" name="nom" id="nom" class="form-control">
        </div>
        <div>
            <label for="description">Description</label>
            <input type="description" name="description" id="description" class="form-control">
        </div>
        <div>
            <label for="prix">Prix</label>
            <input type="prix" name="prix" id="prix" class="form-control">
        </div>
     
        <br>

       
        <button  type="submit" class="btn btn-primary">Valider</button>
    </form>
    
   

</div>

    
</body>
</html>