<?php
require_once ('configuration.php');


$id=$_GET['id'];
$requete = $db->prepare("DELETE FROM produits WHERE id= $id");   
$requete->execute();

header('Location: index.php');

?>