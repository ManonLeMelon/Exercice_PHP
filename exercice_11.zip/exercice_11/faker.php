<?php

//j'insère un fichier une fois
require_once 'vendor/autoload.php';
require_once 'configuration.php';

//instanciation de Faker
$faker=Faker\Factory::create('fr_FR');

//Préparation de la requête SQL d'insertion
$requete =$db->prepare("
INSERT INTO produits (nom, description, prix) VALUE (:nom, :description, :prix)");

//Boucle 100 Fois pour avoir 100 produits
for ($i =0; $i <= 100; $i++){
$requete->bindValue(':nom',$faker->jobTitle, PDO::PARAM_STR);
$requete->bindValue(':description',$faker->realText(300), PDO::PARAM_STR);
$requete->bindValue(':prix', $faker->numberBetween(23,12968), PDO::PARAM_INT);
$requete->execute();
}
?>