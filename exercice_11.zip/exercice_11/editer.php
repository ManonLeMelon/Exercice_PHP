<?php
require_once ('configuration.php');

$id=$_GET['id'];
$requete = $db->prepare("SELECT * FROM produits");  
$requete->execute();
$requete= $requete->fetch(PDO::FETCH_ASSOC);

if(isset($_POST['maj'])){
    $requete = $db->prepare("UPDATE produits SET nom= :nom, description= :description, prix=:prix WHERE id=$id"); 
    $requete->bindValue(':nom', $_POST['nom'], PDO::PARAM_STR);
    $requete->bindValue(':description', $_POST['description'], PDO::PARAM_STR);
    $requete->bindValue(':prix', $_POST['prix'], PDO::PARAM_INT);
    $requete->execute();

    header('Location: index.php');
}


 ?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Formulaire de produits</title>
</head>
<body>

<div class="container py-5 px-3">
    <H1>Formulaire de produits</H1>

    <form method="post">


       
        <div class="form-group">
            <label for="nom">Nom</label>
            <input type="nom" name="nom" id="nom" class="form-control" value='<?php echo $requete['nom'] ?>'>
        </div>
        <div>
            <label for="description">Description</label>
            <input type="description" name="description" id="description" class="form-control" value='<?php echo $requete['description'] ?>'>
        </div>
        <div>
            <label for="prix">Prix</label>
            <input type="prix" name="prix" id="prix" class="form-control" value='<?php echo $requete['prix'] ?>'>
        </div>
     
        <br>

       
        <button name="maj" type="submit" class="btn btn-primary">Modifier</button>
    </form>
    
   

</div>

    
</body>
</html>