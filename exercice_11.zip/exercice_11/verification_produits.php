<?php


session_start();


//connexion des produits

// Insertion du fichier de connexion à la BDD
require_once ('configuration.php');

if(
    isset($_POST['nom']) && !empty($_POST['nom']) &&
    isset($_POST['description']) && !empty($_POST['description']) &&
    isset($_POST['prix']) && !empty($_POST['prix'])

 ){
    $requete = $db->prepare("INSERT INTO produits (nom, description, prix) VALUES (:nom, :description, :prix)");   
    $requete->bindValue(':nom', $_POST['nom'], PDO::PARAM_STR);
    $requete->bindValue(':description', $_POST['description'], PDO::PARAM_STR);
    $requete->bindValue(':prix', $_POST['prix'], PDO::PARAM_INT);
    $requete->execute();

    echo 'Tout les champs sont remplis';

}else{
    echo 'Tous les champs sont obligatoires';
}

?>
